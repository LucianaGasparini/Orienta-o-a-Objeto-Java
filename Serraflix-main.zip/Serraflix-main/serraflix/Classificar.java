package serraflix;

public interface Classificar {

	public void classificar(int classificacao) throws ClassificacaoForaDoRangeException;
	
	
	
}
