package serraflix;

public class ClassificacaoForaDoRangeException extends Exception {

	public ClassificacaoForaDoRangeException(String mensagem) {
        super(mensagem);
    }
	
}